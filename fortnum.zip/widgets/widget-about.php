<?php 

/**
 * Adds Fortnum_About_Widget widget.
 */
class Fortnum_About_Widget extends WP_Widget {

	/**
	 * Register widget with WordPress.
	 */
	function __construct() {
		parent::__construct(
			'Fortnum_About_widget', // Base ID
			__( 'Fortnum About', 'Fortnum' ), // Name
			array( 'description' => __( 'Short information', 'Fortnum' ), ) // Args
		);
	}

	/**
	 * Front-end display of widget.
	 *
	 * @see WP_Widget::widget()
	 *
	 * @param array $args     Widget arguments.
	 * @param array $instance Saved values from database.
	 */
	public function widget( $args, $instance ) {

		//get values from option settings
		$Fortnum_about_textarea =  $instance['Fortnum_about_textarea'];

		$Fortnum_about_url =  $instance['Fortnum_about_url'];
		$Fortnum_logo =  get_template_directory_uri().'/assets/images/logo-footer.png';

		//logo
		echo "<div class=\"widget-logo\"><img src=\"";
		echo __( esc_attr( $Fortnum_logo ), 'Fortnum' );
		echo "\" /></div>";
		
		//excerpt
		echo "<div class=\"widget-about-content\">";
		echo preg_replace( '/\n/', '<br />', $Fortnum_about_textarea );
		echo "</div>";

		//read more url
		echo "<div class=\"widget-url\">";
		echo "<a href='".$Fortnum_about_url."'><i class=\"fa fa-angle-right\"></i>";
		echo __( esc_attr( 'Read more' ), 'Fortnum' );
		echo "</a>";
		echo "</div>";

		echo $args['after_widget'];
	}

	/**
	 * Back-end widget form.
	 *
	 * @see WP_Widget::form()
	 *
	 * @param array $instance Previously saved values from database.
	 */
	public function form( $instance ) {
		/* Set up some default widget settings. */
		$blogname = get_bloginfo( 'name' );
		$defaults = array( 
			'Fortnum_about_textarea' => 'We have been in the business of supplying livestock management solutions around Australia and worldwide for over 30 years - and we still love our work!

Fortnum Stockyards was established by Ian and ',
			'Fortnum_about_url' => '#',
		 );

		$instance = wp_parse_args( (array) $instance, $defaults );


		if ($instance){

			//textarea
			$Fortnum_about_textarea = esc_attr($instance['Fortnum_about_textarea']);

			//textarea
			$Fortnum_about_url = esc_attr($instance['Fortnum_about_url']);
		}

		else
		{
			$Fortnum_about_textarea = '';
			$Fortnum_about_url = '';

		}

		?>

		<!-- About textbox -->
		<p class="Fortnum">
			<label for="<?php echo $this->get_field_id('Fortnum_about_textarea'); ?>" class="asterisk Fortnumsocial">
				About excerpt <i>(max 33 words)</i>
			</label>

			<textarea cols="30" rows="7" class="widefat input_Fortnum_about_textarea" id="<?php echo $this->get_field_id('Fortnum_about_textarea'); ?>"  
			name="<?php echo $this->get_field_name('Fortnum_about_textarea'); ?>"
			><?php echo $Fortnum_about_textarea; ?></textarea>

		</p>

		<!-- About learn mroe link -->
		<p class="Fortnum">
			<label for="<?php echo $this->get_field_id('Fortnum_about_url'); ?>" class="asterisk Fortnumsocial">
				Read more url
			</label>

			<input type="text" cols="30" rows="7" class="widefat input_Fortnum_about_url" id="<?php echo $this->get_field_id('Fortnum_about_url'); ?>"  
			name="<?php echo $this->get_field_name('Fortnum_about_url'); ?>"
			value="<?php echo $Fortnum_about_url; ?>";
			>

		</p>
		<?php 
	}

	/**
	 * Sanitize widget form values as they are saved.
	 *
	 * @see WP_Widget::update()
	 *
	 * @param array $new_instance Values just sent to be saved.
	 * @param array $old_instance Previously saved values from database.
	 *
	 * @return array Updated safe values to be saved.
	 */
	public function update( $new_instance, $old_instance ) {
		$instance = $old_instance;
			//fields
			$instance['Fortnum_about_textarea'] = strip_tags($new_instance['Fortnum_about_textarea']);
			$instance['Fortnum_about_url'] = strip_tags($new_instance['Fortnum_about_url']);
			
			return $instance;
	}

} // class Fortnum_About_Widget

// register Fortnum_About_Widget widget
function register_Fortnum_About_widget() {
    register_widget( 'Fortnum_About_Widget' );
}
add_action( 'widgets_init', 'register_Fortnum_About_widget' );

?>